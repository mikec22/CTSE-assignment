public interface Memento {
    void restore();
}