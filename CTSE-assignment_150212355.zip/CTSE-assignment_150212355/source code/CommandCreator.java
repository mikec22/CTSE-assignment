public abstract class CommandCreator {
    public abstract Command createCommand();
}